/*
 * 1.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
 */
#include<stdio.h>

int isprime(int n);
int count(int *a,int n);
int main()
{
	int a[100],n,*p;
	p=a;
	printf("enter n:");
	scanf("%d",&n);

	for(int i=0;i<n;i++){
		scanf("%d",(p+i));
	}

	printf("%d",count(a,n));
	return 0;
}

int isprime(int n)
{
if (n <= 1) {
        return 0; // Numbers <= 1 are not prime
    }

	for(int i=2;i*i<=n;i++){
		if(n%i==0){
			return 0;
		}
	}

	return 1;
}



int count(int *a,int n)
{
	int count=0;

	for(int i=0;i<n;i++){
		if(isprime(*(a+i))){
			count++;
		}
	}
	return count;
}
