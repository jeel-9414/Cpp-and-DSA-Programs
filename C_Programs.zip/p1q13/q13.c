/*

 * q13.c
 *
 *  Created on: 25 Mar 2025
 *      Author: nikul
*/
#include<stdio.h>
int date(int ,int ,int );
int main()
{
	setvbuf(stdout, NULL, _IONBF, 0);

	int d,m,y;
	printf("enter date here:");
	scanf("%d %d %d",&d,&m,&y);

	printf("the date is=%d",date(d,m,y));
	return 0;
}

int date(int d,int m,int y)
{
	if(y<1900 ||y>2100){
		return 1;
	}if(m<1 || m>12){
		return 1;
	}if(d<1 || d>31){
		return 1;
	}

	 if(m==2){
		if(y%4==0 && (y%100!=0 || y%400==0)){
			 if(d<1 || d>29){
				 return 1;
			 }
		}
		else if(d<1 || d>28){
				 return 1;
			 }

	}

	 if(m==1 || m==3 || m==5 || m==7 || m==8 || m==10 || m==12){
		if(d<1 || d>31){
			return 1;
		}
	}

	 if(m==4 || m==6 || m==9 || m==11){
		if(d<1 || d>30){
			return 1;
		}
	}

	return 0;
}


