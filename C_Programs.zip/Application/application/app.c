// #include <stdio.h>
// #include <stdlib.h>
// #define pf printf
// #define  FILENAME "UIAI"
// typedef struct
// {
//     int d, m, y;
// } date;

// typedef struct
// {
//     long int ano;
//     char name[20];
//     date dob;
//     char gender[20];

//     date i_date;
//     long int mno;
//     char address1[25];
//     char address2[25];
//     int pincode;
// } person;

// void insert();
// void display();
// void printline();
// // void printmenu();
// void header();


// int main()
// {
// 	insert();
// 	header();

//     display();
//     return 0;
// }

// void printline() {
// 	printf("\n");
// 	for (int i = 0; i <= 80; i++) {

// 		printf("-");

// 	}
// 	printf("\n");
// }

// void header() 
// {
// 	printline();

// 	printf("\n%-15s%-25s%-12s%-10s%-13s%-15s%-20s%-20s%-7s", "Addhar no",
// 			"Name", "Birth Date", "Gender", "Issue Date", "Mobile NO",
// 			"Address Line 1", "Address Line 2", "Pincode");

// 	printline();
// }

// void insert() {
// 	person p;
// 	FILE *fp;

// 	fp = fopen(FILENAME, "a+");
// 	if (fp == NULL) {
// 		printf("Error:File Doesn't exist\n");
// 	}

// 	e: printf("\nEnter Your Aadhar Number Here: ");
// 	scanf("%ld", &p.ano);

// 	rewind(fp);
// 	person temp;
// 	temp.ano = p.ano;
// 	int count = 0;

// 	while (fread(&p, sizeof(p), 1, fp)) {
// 		if (p.ano == temp.ano) {
// 			count++;
// 		}
// 	}

// 	if (count > 0) {
// 		printf("Already Exist Number\n");
// 		goto e;
// 	}
	
// 	printf("Enter name, birth date, gender : ");
// 	scanf("%s %d %d %d %s", p.name, &p.dob.d, &p.dob.m, &p.dob.y, p.gender);
	
// 	printf("Enter mobile no & issue date : ");
// 	scanf("%ld %d %d %d", &p.mno, &p.i_date.d, &p.i_date.m, &p.i_date.y);
	
// 	printf("Enter Address line 1 & 2 = ");
// 	scanf("%s", p.address1, p.address2);
	
// 	printf("Enter pincode = ");
// 	scanf("%d", &p.pincode);
	
// 	fwrite(&p, sizeof(p), 1, fp);

// 	fclose(fp);
// }

// // void display() {
// // 	person p;
// // 	FILE *fp;
// // 	int count = 0;
// // 	fp = fopen(FILENAME, "r");
// // 	if (fp == NULL) {
// // 		printf("Error in opening file \n");
// // 		exit(-1);
// // 	}
// // 	printf("\n");
// // 	// printline();
// // 	header();
// // 	// printline();
// // 	while (fread(&p, sizeof(p), 1, fp)) {
// // 		count++;
// // 		printf("\n%ld\t\t%s\t\t%d\t%d\t%d\t%s\t\t%d\t%d\t%d\t%ld\t\t%s\t\t%s\t\t%d\n",
// // 		 p.ano, p.name, p.dob.d, p.dob.m, p.dob.y, p.gender, p.i_date.d,
// // 		 p.i_date.m, p.i_date.y, p.mno, p.address1, p.address2,
// // 		 p.pincode);
// // 	}
// // 	printf("\n %d records displayed", count);
// // 	fclose(fp);
// // }

#include<stdio.h>
#define FILENAME "UIAI"
typedef struct {
	int d, m, y;
} date;

typedef struct {
	long int ano;
	char name[20];
	date dob;
	char gender[20];

	date i_date;
	long int mno;
	char address1[25];
	char address2[25];
	int pincode;
} person;

void insert();
/*
 void search();
 void searchbyano();
 void searchbyname();
 void searchbydob();
 void searchbygender();
 void searchbyi_date();
 void searchbypincode();
 void update();
 void updatebyname();
 void updatebydob();
 void updatebygender();
 void updatebyi_date();
 void updatebymno();
 void updatebyaddress1();
 void updatebyaddress2();
 void updatebypincode();
 void delete();
 void sort();
 void sortbyano();
 void sortbyname();
 void sortbypincode();
 void sortbygender();*/
void display();
void printline();
void printmenu();
void header();
//void count();

int main() {

	header();
	insert();
	display();
	return 0;
}

void printline() {
	printf("\n");
	for (int i = 0; i <= 122; i++) {

		printf("-");

	}
	printf("\n");
}

int count() {
	person p;
	FILE *fp;
	int count = 0;
	fp = fopen(FILENAME, "r");
	if (fp == NULL) {
		printf("Error in opening file \n");
		exit(-1);
	}
	while (fread(&p, sizeof(p), 1, fp)) {
		count++;
	}
	fclose(fp);
	return count;

}

void header() {
	printline();

	printf("\n%s\t%s\t\t%s\t%s\t%s\t%s\t%s\t\t%s\t", "Addhar no", "Name",
			"Birth Date", "Gender", "Issue Date", "Mobile NO", "Address Line 1",
			"Pincode");

	printline();
}

void insert() {
	person p;
	FILE *fp;

	fp = fopen(FILENAME, "w");
	if (fp == NULL) {
		printf("Error:File Doesn't exist\n");
	}

	e: printf("\nEnter Your Aadhar Number Here: ");
	scanf("%d", &p.ano);

	rewind(fp);
	person temp;
	temp.ano = p.ano;
	int count = 0;

	while (fread(&p, sizeof(p), 1, fp)) {
		if (p.ano == temp.ano) {
			count++;
		}
	}

	if (count > 0) {
		printf("Already Exist Number\n");
		goto e;
	}
	printf("Enter name, birth date, gender : ");
	scanf("%s %d %d %d %s", p.name, &p.dob.d, &p.dob.m, &p.dob.y, p.gender);

	printf("Enter mobile no & issue date : ");
	scanf("%ld %d %d %d", &p.mno, &p.i_date.d, &p.i_date.m, &p.i_date.y);

	printf("Enter Address line 1 & 2 = ");
	scanf("%s", p.address1, p.address2);

	printf("Enter pincode = ");
	scanf("%d", &p.pincode);
	fwrite(&p, sizeof(p), 1, fp);

	fclose(fp);
}

void display() {
	person p;
	FILE *fp;
	int count = 0;
	fp = fopen(FILENAME, "a+");
	if (fp == NULL) {
		printf("Error in opening file \n");
		return;
	}
	printf("\n");
	printline();
	header();
	printline();
	while (fread(&p, sizeof(p), 1, fp)) {
		count++;
		printf("\n%ld\t\t%s\t\t\t%d-%d-%d\t\t\t%s\t\t%d-%d-%d\t\t%ld\t\t%s\t\t\t%d\n",
				p.ano, p.name, p.dob.d, p.dob.m, p.dob.y, p.gender, p.i_date.d,
				p.i_date.m, p.i_date.y, p.mno, p.address1,p.pincode);
	}
	printf("\n %d records displayed", count);
	fclose(fp);
}